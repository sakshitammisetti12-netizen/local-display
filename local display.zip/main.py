from machine import Pin, I2C
import ssd1306
import dht
import time

# ---------- I2C SETUP ----------
i2c = I2C(0, scl=Pin(5), sda=Pin(4))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

# ---------- SENSOR SETUP ----------
sensor = dht.DHT22(Pin(16))

print("I2C HMI System Started")

while True:
    try:
        sensor.measure()
        temp = sensor.temperature()
        hum = sensor.humidity()

        # Clear display
        oled.fill(0)

        # Display text
        oled.text("ENVIRONMENT", 0, 0)
        oled.text("Temp: {:.1f} C".format(temp), 0, 20)
        oled.text("Hum : {:.1f} %".format(hum), 0, 35)

        oled.show()

        print("Temp:", temp, "C | Hum:", hum, "%")

    except OSError:
        oled.fill(0)
        oled.text("Sensor Error", 0, 30)
        oled.show()
        print("DHT22 error")

    time.sleep(2)
